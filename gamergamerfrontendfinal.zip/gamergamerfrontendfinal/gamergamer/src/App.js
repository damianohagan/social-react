import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Link, Route, Redirect, Switch } from 'react-router-dom';
import Loading from './components/Loading';
import './App.scss';
import axios from 'axios';
import Navbar from './nav/Navbar';
import Login from './components/Login';
import Register from './components/Register';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import News from './pages/News';
import Social from './pages/Social';
import Games from './pages/Games'
import Forgot from './components/Forgot';
import Reset from './components/Reset';
import Profile from './components/Profile';
import PuffLoader from "react-spinners/PuffLoader";
import Apex from './pages/Apex';
import Csgo from './pages/Csgo';
import Overwatch from './pages/Overwatch';
import Valorant from './pages/Valorant';
import LeagueofLegends from './pages/League';
import League from './pages/League';
import Createpost from './components/Createpost';

axios.defaults.withCredentials = true;

function App() {

  const [user, setUser] = useState(null);
  const [login, setLogin] = useState(false);

  useEffect( () => {
    (
        async () => {
            try {
            const response = await axios.get('user');
            
            const user = response.data;
        
              setUser(user)
        } catch (e) {
           setUser(null)
        }
    }
    )();
}, [login]);
  

// Loading Feature

const [loading, setLoading] = useState(false);

useEffect(() => {
    setLoading(true)

    setTimeout(() => {
      setLoading(false)
    }, 1000)
}, []) 


  return (
    <div className="App">

      {
        loading ?
<div className='loader'>
          <PuffLoader 
          
        
          size={160}
          color={"#25E67B"}
          loading={loading}
          
          />
</div>
        :

        <Router>
        <Navbar user={user} setLogin={() => setLogin(false)}/>
        <main>
          <Switch>
            <Route path='/' exact component={Home}>
              <Home />
            </Route>

            <Route path='/dashboard'>
              <Dashboard user={user} />
            </Route>

            <Route path='/news' component={News}>
              <News />
            </Route>

            <Route path='/social' component={Social}>
              <Social />
            </Route>

            <Route path='/games' component={Games}>
              <Games />
            </Route>

            <Route path='/login' component={Login}>
              <Login setLogin={() => setLogin(true)} />
            </Route>
           
            <Route path='/register' component={Register}>
              <Register />
            </Route>

            <Route path='/forgot' component={Forgot}>
              <Forgot />
            </Route>

            <Route path='/reset/:token' component={Reset}>
              <Reset />
            </Route>

        <Route path='/profile' component={Profile}>
          <Profile user={user}/>
        </Route>

        <Route path='/create-post' component={Createpost}>
        <Createpost />
        </Route>

        <Route path='/overwatch' component={Overwatch}>
        <Overwatch />
        </Route>
           
            
            <Redirect to='/' />
          </Switch>
        </main>
      </Router>
      }
      
    </div>
  );
}

export default App;
