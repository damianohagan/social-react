import React from 'react'

function Loading() {
    return (
        <div>
            
        </div>
    )
}

export default Loading
