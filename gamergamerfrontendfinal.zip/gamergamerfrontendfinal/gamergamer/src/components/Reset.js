import React, { useState } from 'react'
import axios from 'axios'
import { Redirect } from 'react-router-dom';
function Reset({ match }) {

    const [password, setPassword] = useState('');
    const [passwordConfirm, setPasswordConfirm] = useState('');
    const [redirect, setRedirect] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        const token = match.params.token;

        await axios.post('reset', {
            token,
            password,
            password_confirmation: passwordConfirm
        });

        setRedirect(true);

    }

    if(redirect){
        return <Redirect to="/login"/>
    }


    return (
        <div className="background" >
        <form class="form-signin" onSubmit={submit}> 
        
       
            <h1 class="h3 mb-3 font-weight-normal">Reset Password</h1>
            <label for="inputEmail" className="sr-only">Password</label>
            <input type="password" id="inputEmail" class="form-control" placeholder="Password" required autofocus onChange={e => setPassword(e.target.value)} />
      


                <label for="inputPassword" className="sr-only">Confirm Password</label>
            <input type="password" id="inputPassword" class="form-control" placeholder="Confirm Password" required autofocus onChange={e => setPasswordConfirm(e.target.value)} />
            

            
            <button className="btn btn-lg btn-primary btn-block" type="submit">Password Reset</button>
        </form>
    </div>
    )
}

export default Reset
