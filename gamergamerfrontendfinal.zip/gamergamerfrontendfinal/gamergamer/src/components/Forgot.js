import React, {useState} from 'react'
import { Link, NavLink, Redirect } from 'react-router-dom';
import axios from 'axios'

function Forgot() {

    const [email, setEmail] = useState('');
    
    const [notify, setNotify] = useState({
        show: false,
        error: false,
        message: ''

    });

    const submit = async (e) => {
        e.preventDefault();

        try{
        await axios.post('forgot', {email});

        setNotify({
            show: true,
            error: false,
            message: 'Email was sent'
        })
    } catch(e) {
        setNotify({
            show: true,
            error: true,
            message: 'Email does not exist in our records'
        })
    }

}


let info;


if(notify.show){
    info = (
        <div className={notify.error ? 'alert alert-danger' : 'alert alert-success'} role='alert'>
            {notify.message}
        </div>
    )
} 


    return (
        <div className="background" >
            <form class="form-signin" onSubmit={submit}> 
                {info}
           
                <h1 class="h3 mb-3 font-weight-normal">Please Enter your Email</h1>
                <label for="inputEmail" className="sr-only">Email address</label>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus onChange={e => setEmail(e.target.value)} />
                <div className>

                </div>
                <button className="btn btn-lg btn-primary btn-block" type="submit">Send Email</button>
            </form>
        </div>
    )
}

export default Forgot
