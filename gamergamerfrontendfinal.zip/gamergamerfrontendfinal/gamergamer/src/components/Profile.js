import React from 'react'
import Card from './Card';

function Profile({ user }) {
    return (
        <div className='profile'>
            <div>
                <div className="usercoverimage">
                <Card user={user}/>
                </div>
               
            </div>
        </div>
    )
}

export default Profile
