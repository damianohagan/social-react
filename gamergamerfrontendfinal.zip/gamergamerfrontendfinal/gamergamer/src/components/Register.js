import React, { useState, useEffect } from 'react'
import './loginandregister.scss';
import { Link, NavLink, Redirect } from 'react-router-dom';
import * as MdIcons from 'react-icons/md';
import axios from 'axios';

function Register() {

    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [dateofbirth, setDateofBrith] = useState('');
    const [redirect, setRedirect] = useState(false);

    const submit = async (e) => {
        e.preventDefault();

        const response = await axios.post('register', {
            username: username,
            email: email,
            password: password,
            password_confirmation: confirmPassword,
            date_of_birth: dateofbirth
        });

        setRedirect(true);
    }

    if(redirect) {
        return <Redirect to='/login'/>
    }






    return (
        <div className="background" onSubmit={submit}>
            <form class="form-signin">
                <Link to='/'>
                    <MdIcons.MdClose className="close" aria-label='Close Login' />
                </Link>
                <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
                <label for="inputUsername" className="sr-only">Username</label>
                <input type="text" id="inputEmail" className="form-control" placeholder="Username" required  onChange={e => setUsername(e.target.value)} />

                <label for="inputEmail" className="sr-only">Email address</label>
                <input type="email" id="inputEmail" className="form-control" placeholder="Email address" required  onChange={e => setEmail(e.target.value)}/>

                <label for="inputPassword" className="sr-only">Password</label>
                <input type="password" id="inputPassword" className="form-control" placeholder="Password" required onChange={e => setPassword(e.target.value)} />

                <label for="inputConfirmPassword" className="sr-only">Confirm Password</label>
                <input type="password" id="inputPassword" className="form-control" placeholder="Confirm Password" required  onChange={e => setConfirmPassword(e.target.value)}/>

                <label for="inputdateofbirth" className="sr-only">Date of Birth</label>
                <input type="date" id="inputPassword" className="form-control" placeholder="Date of Birth" required  onChange={e => setDateofBrith(e.target.value)}/>

                <div className="checkbox mb-3">
                </div>
                <button className="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
            </form>
        </div>
    )
}

export default Register
