import React from 'react'

function Apexicon({ fill, height, width }) {
    
    return (
     
<svg width={width} height={height} viewBox="0 0 1600 1200" version="1.1" xmlns="http://www.w3.org/2000/svg">
    <title>Apex Legends Symbol</title>
    <defs></defs>
    <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="apexicon" transform="translate(285.000000, 100.000000)" fill={fill} fillRule="nonzero">
            <polygon id="Triangle-Copy" points="515.151515 0 1030.30303 878.787879 878.787879 1000 589.767918 803.070992 757.451838 803.070992 515.151515 378.787879 273.624305 803.070992 439.499364 803.070992 151.515152 1000 0 878.787879"></polygon>
        </g>
    </g>
</svg>
    )
}

export default Apexicon
