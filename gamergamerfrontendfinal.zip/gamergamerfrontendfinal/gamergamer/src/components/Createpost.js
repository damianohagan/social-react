import React, { useState } from 'react'
import './loginandregister.scss';
import { Link, NavLink, Redirect } from 'react-router-dom';
import * as MdIcons from 'react-icons/md';
import axios from 'axios';


function Createpost() {

    const [post, usePost] = useState("");

    const posting = async (e) => {
        e.preventDefault();
             

    }




    return (



        <div className="background" >
                  <form class="form-signin" onSubmit={posting}>
                <Link to='/'>
                    <MdIcons.MdClose className="close" aria-label='Close Login' />
                </Link>
                <h1 class="h3 mb-3 font-weight-normal">Create Post</h1>
                <label for="inputEmail" className="sr-only">Select Game</label>
                <input type="dropdown" id="inputEmail" class="form-control" placeholder="Email address" required autofocus/>

                <label for="inputPassword" className="sr-only">What are you looking for?</label>
                <input type="textarea" id="inputPassword" className="form-control" placeholder="Password" required />

                <label for="inputPassword" className="sr-only">Availability to Play?</label>
                <input type="textarea" id="inputPassword" className="form-control" placeholder="Password" required />

                <label for="inputPassword" className="sr-only">Select game mode</label>
                <input type="dropdown" id="inputPassword" className="form-control" placeholder="Password" required />

                <label for="inputPassword" className="sr-only">Select Role </label>
                <input type="dropdown" id="inputPassword" className="form-control" placeholder="Password" required />

                <label for="inputPassword" className="sr-only">Add Links</label>
                <input type="text" id="inputPassword" className="form-control" placeholder="Password" required />

                <button className="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
       
            </form>
        </div>
    )
}

export default Createpost
