import React, { useState } from 'react';
import '../App.scss';

function Card({ user }) {

 const [description, setDescrition] = useState('Lorem ipsum dolor sit amet, consectetur adipiscing elit. In quis est elementum, pretium erat in, placerat nunc. In rhoncus rutrum ex at aliquet.');


    return (
        <div className="card">
            <div className="upper-container">
                <div className="image-container ">
                <img src="" alt="" height='100px' width="100px" />

                </div>
            </div>
            <div className="lower-container">
                <h3> {user.username} </h3>
                <h4> {user.county_id} </h4>
                <p> {description} </p>

         </div>
    </div>
       
    )
}

export default Card
