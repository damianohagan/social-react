import React, { useState } from 'react'
import './loginandregister.scss';
import { Link, NavLink, Redirect } from 'react-router-dom';
import * as MdIcons from 'react-icons/md';
import axios from 'axios';



function Login({ setLogin }) {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [redirect, setRedirect] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        
        await axios.post('login', {
            email: email,
            password: password,

        });
        setRedirect(true);
        setLogin();
    }

    if(redirect){
        return <Redirect to='/dashboard'/>
    }

    // axios.get('/sanctum/csrf-cookie').then(response => {
    //     console.log(response);
    // });

    return (
        <div className="background" >
                  <form class="form-signin" onSubmit={submit}>
                <Link to='/'>
                    <MdIcons.MdClose className="close" aria-label='Close Login' />
                </Link>
                <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
                <label for="inputEmail" className="sr-only">Email address</label>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus  onChange={e => setEmail(e.target.value)}/>

                <label for="inputPassword" className="sr-only">Password</label>
                <input type="password" id="inputPassword" className="form-control" placeholder="Password" required  onChange={e => setPassword(e.target.value)}/>

                <div className="checkbox mb-3">
                </div>
                <button className="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>

                <div className="forgot-password mb-3">
                    <Link to='/forgot'>Forgot your password?</Link>
                </div>
            </form>
        </div>
    )
}

export default Login
