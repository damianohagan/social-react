import React from 'react'

function Apex() {
    return (
        <div>
            <h1>Apex Legends</h1>
        </div>
    )
}

export default Apex
