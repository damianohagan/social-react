import React from 'react'

function Social() {
    return (
        <div>
            <h1>Social</h1>
        </div>
    )
}

export default Social
