import React from 'react'

function Valorant() {
    return (
        <div>
            <h1>Valorant</h1>
        </div>
    )
}

export default Valorant
