import React from 'react';
import axios from 'axios';



function Dashboard({ user }) {


    let message;

    if(user) {
        message = `HI ${user.username}`
    }else {
        message = 'you are not logged in!'
    }


    return (
        <div>
            <h1>Dashboard</h1>
            <h2>{message}</h2>
            
        </div>
    )
}

export default Dashboard
