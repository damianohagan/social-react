import React from 'react'

function Csgo() {
    return (
        <div>
            <h1>Counter Strike Global Offensive</h1>
        </div>
    )
}

export default Csgo
