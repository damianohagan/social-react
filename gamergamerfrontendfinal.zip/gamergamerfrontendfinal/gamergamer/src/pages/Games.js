import React from 'react'
import { Link, Route, NavLink } from 'react-router-dom';
import './Games.scss';
import Apexicon from '../components/Apexicon';
import Leagueicon from '../components/Leagueicon';
import Overwatchicon from '../components/Overwatchicon';
import CsgoIcon from '../components/CsgoIcon';
import Valoranticon from '../components/Valoranticon';
import Apex from '../pages/Apex';
import Csgo from '../pages/Csgo';
import Overwatch from '../pages/Overwatch';
import Valorant from '../pages/Valorant';
import LeagueofLegends from '../pages/League';
import League from '../pages/League';
import { Button } from 'react-bootstrap';
import Createpost from '../components/Createpost';


function Games() {
    return (
        <div className='gamedisplay'>
            <div className='gamelinklist'>
            <ul className='game-links'>
            <li className="link-items">
                    <Link to='/games/all' >All </Link> 
                </li>
                <li className="link-items">
                    <Link to='/games/apex-legends' >Apex Legends </Link> 
                </li>
                <li className="link-items">
                    <Link to='/games/counter-strike-global-offensive' > Csgo </Link> 
                </li>
                <li className="link-items">
                    <Link to='/overwatch' > Overwatch </Link> 
                </li>
                <li className="link-items">
                    <Link to='/games/valorant' > Valorant </Link> 
                </li>
                <li className="link-items">
                    <Link to='/games/league-of-legends' > LeagueofLegends </Link> 
                    
                </li>
                <li className="link-items">
                    <Link to='/games/create-post' > Create post </Link> 
                    
                </li>
            </ul>
            </div>

            <div className="displayposts">

            </div>


   <div className="gamecard">

            <div className="gameupper-container">
          <Link  className='createpost btn btn-primary' to='/create-post' excat>
            Create Post
            </Link>
            </div>
            
    </div>


        </div> 
    )
}

export default Games
