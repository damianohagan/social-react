import React from 'react'

function League() {
    return (
        <div>
            <h1>League of Legends</h1>
        </div>
    )
}

export default League
