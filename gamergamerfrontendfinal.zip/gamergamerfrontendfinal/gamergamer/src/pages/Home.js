import React, { useState, useEffect } from 'react';
import '../App.scss';
import axios from 'axios';
function Home() {



    return (
        <div>

            <header class="masthead text-center text-white">
                <div class="masthead-content">
                    <div class="container">
                        <h1 class="masthead-heading mb-0">Gamer Gamer </h1>
                        <h3 class="sub mb-0">Finding the Right Games for the Right Gamers</h3>
                        <p className="caption">Online gaming communication platform to help seek all leveled gamers from Pro to Casual!</p>
                       
                    </div>
                </div>
            </header>


            <section>
                <div class="container">
                    <div class="row align-items-left">
                        <div class="col-lg-5 order-lg-2">
                            <div class="p-5">
                                <img class="img-fluid rounded-circle" src="img/01.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-lg-5 order-lg-">
                            <div class="p-5">
                                <h2 class="display-4">Seeking the Right Player's</h2><br/>
                                <p>Finding the right players isn't easy and we know the struggle. This application allows the access to multiple player's who have signed up on this platform to seek, commnunicate and even form a team. We encorage gamers to come forward and support there gaming choices.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <footer class="py-5 bg-black">
             

            </footer>







        </div>
    )
}

export default Home
